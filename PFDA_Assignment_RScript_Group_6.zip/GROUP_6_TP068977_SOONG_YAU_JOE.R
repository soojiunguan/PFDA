#Soong Yau Joe, TP068977

#LIBRARY
#############
install.packages("tidyverse")
install.packages("ggplot2")
install.packages("colorspace")
install.packages("plotrix")
install.packages("pastecs")
install.packages("devtools")
install.packages("gganimate")
install.packages("gifski")
install.packages("ggpmisc")
devtools::install_github("thomasp85/patchwork")
library(ggpmisc)
library(gganimate)
library(gifski)
library(patchwork)
library(pastecs)
library(tidyverse)
library(ggplot2)
library(plotrix)
library(colorspace)
library(dplyr)
library(dunn.test)
#############


# DATA PREPARATION
#==============================================================================
# IMPORT DATASET

rental_data <- read.csv("/Users/yaujoesoong/Downloads/APU/Courses materials/Year 2/Y2S1/PFDA/PFDA Assignment/House_Rent_Dataset.csv", 
                        header = TRUE)


# DATA EXPLORATION
rental_data <- na.omit(rental_data)
nrow(rental_data)

rental_data <- unique(rental_data)
nrow(rental_data)

View(rental_data)
names(rental_data)

# Shapiro-Wilk Normality Test
# The function is use to test out whether the variable data is normally distributed
# H0: There is no significance difference of the shape of data with the shape of normal distribution
# H1: There is significance difference of the shape of data with the shape of normal distribution
shapiro.test(rental_data3$Size)
shapiro.test(rental_data3$Rent)


# DATA CLEANING
# There are two special rows which contains "Built Area" as Area Type
# Another one special row contain "Contact Builder" as it's point of contact
unique(rental_data$Point.of.Contact)
unique(rental_data$Area.Type)
View(filter(rental_data2, rental_data2$Area.Type == "Built Area"))
View(filter(rental_data2, rental_data2$Point.of.Contact == "Contact Builder"))

# REMOVE OUTLIERS FROM BANGALORE
rental_data2 <- rental_data %>% filter(Rent != 3500000 & Rent != 1200000 & Rent !=1000000 & 
                                         Area.Type!="Built Area" & Point.of.Contact!="Contact Builder")



#===============================================================================




# DATA ANALYSIS

#=====================================================================================================#
# Objective 1 : Find out the relationship between rental fees and the tenant preferred by the lessor? #
#=====================================================================================================#
#                                   Analysis 5.1.1
#     Which types of tenant are most preferred by the lessor in every cities?
#############
# The code below shows the information of rent across different cities

# The code below is to assign distinct values of certain variable into a new variable
# for the use in for loop section
City_Name <- unique(rental_data2$City)
Tenant_Type <- unique(rental_data2$Tenant.Preferred)


# The code shows the total number of every type of tenant preferred across different cities
numb_tenant_acity <- select(rental_data2, c("Rent", "City", "Tenant.Preferred")) %>%
  group_by(City, Tenant.Preferred) %>%
  summarise(number=n(), .groups = 'drop')

ggplot(numb_tenant_acity, aes(x=Tenant.Preferred, y=number, fill=number))+
  geom_bar(stat = 'identity')+
  scale_fill_gradient(low = "beige", high = "maroon")+
  facet_wrap(~City)+
  geom_text(aes(label=number, vjust=-0.1))+
  ggtitle("Number of Different Tenant Preferred Type Across Cities")+
  theme(plot.title = element_text(face="bold", hjust = 0.5))+
  theme(text = element_text(family = "Courier"))


# The code below is the FUNCTION to calculate the percentage of different tenant preferred
# in a specific city
tenant_percentage <- function(numbOfCity, numbOfTenant)
{
  tenantOfCityTable <- filter(rental_data2, City == numbOfCity)
  tenantOfCityTable2 <- filter(rental_data2, City==numbOfCity & Tenant.Preferred==numbOfTenant)
  
  total_tenant <- nrow(tenantOfCityTable)
  specific_tenant <- nrow(tenantOfCityTable2)
  
  tenant_proportion <- round((specific_tenant / total_tenant) *100 , digits = 2)
  
  print(sprintf("%s --- %s", numbOfTenant, tenant_proportion))
}


# The code below displays the proportion of every tenant preferred across different cities
for (i in 1:length(City_Name))
{
  cat("\n")
  print(sprintf("PERCENTAGE OF EVERY TENANT PREFERRED IN %s ", City_Name[i]))
  for(j in 1:length(Tenant_Type))
  {
    tenant_percentage(City_Name[i], Tenant_Type[j])
  }
}

##############

#                                   Analysis 5.1.2
#     How do tenant preferred by the lessor affect the rent across different cities?
#############
# The code below shows the information of rent across different cities


# The code below shows the bar chart of average rent across different city
avg_rent = select(rental_data2, c("Rent", "City")) %>% group_by(City) %>%
  summarise(AVG_RENT = round(mean(Rent), digits = 0) )

color_combination3 = c("#ffe1ed", "#ec9ca6", "#db598a", "#af6671", "#6b3c37", "#a45745")

ggplot(avg_rent, aes(x=City, y=AVG_RENT, ylab="Average Rent")) +
  geom_bar(stat = "identity", fill=color_combination3) +
  geom_text(aes(label=AVG_RENT, vjust=-0.05))+
  theme(axis.text.x = element_text(angle = -30, hjust = 1))+
  theme(plot.title = element_text(face = "bold", hjust = 0.5))+
  ggtitle("Average Rent Across Cities")+
  theme(text = element_text(family = "Courier"))+
  theme(axis.text.x = element_text(angle = 30, vjust = 1, hjust = 1))


# The code below shows the bar chart of average rent of different types of
# preferred tenant across different cities
TP_vs_Rent <- rental_data2%>%select(c("City", "Tenant.Preferred","Rent"))%>%
  group_by(City, Tenant.Preferred)%>%
  summarise(AVG_RENT = mean(Rent), .groups = 'drop')

color_combination <- c("tan","peachpuff1", "moccasin","lightgoldenrod","sandybrown", "lightsalmon")

ggplot(TP_vs_Rent, aes(x=Tenant.Preferred, y=AVG_RENT, fill=City))+
  geom_bar(stat = 'identity')+
  facet_wrap(~City)+
  scale_fill_manual(values = color_combination)+
  geom_text(aes(label=round(AVG_RENT, digits = 2), vjust=-0.05, family="Courier"))+
  ggtitle("Average Rent Vs Preferred Tenant Across Cities")+
  theme(axis.text.x = element_text(angle = 30, vjust = 1, hjust = 1))+
  theme(text = element_text(family = "Courier"))+
  theme(plot.title = element_text(hjust = 0.5), legend.position = "none")


# Plot a boxplot to determine the existence of the outliers
TP_vs_Rent2 <- rental_data2%>%select(c("City", "Tenant.Preferred","Rent"))%>%
  group_by(City, Tenant.Preferred)

color_combination4 <- c("#f9e3c9", "#ccbcbf", "#b296b1", "#d799a9", "#ad4d8f", "#8a3c8a")

ggplot(TP_vs_Rent2, aes(x=Tenant.Preferred, y=Rent, fill=City))+
  geom_boxplot()+
  facet_grid(~City)+
  scale_fill_manual(values =  color_combination4)+
  theme(axis.text.x = element_text(angle = 30, hjust = 1))+
  ggtitle("Rent vs Tenant.Preferred Across Cities")+
  theme(text = element_text(family = "Courier"))+
  theme(plot.title = element_text(face = "bold", hjust = 0.5))

# Data trimming to remove outliers based on the boxplot
# List out the top 10 highest rent on every city to help in data trimming
rental_data3 %>%
  select(c("Rent", "Tenant.Preferred", "City"))%>%
  filter(City=="Kolkata")%>%
  arrange(desc(Rent))%>%
  head(10)

# Trim by using filter
rental_data3 <- rental_data2 %>% 
  filter(City!="Mumbai"| Rent<450000)%>% 
  filter(City!="Chennai"| Rent<280000)%>% 
  filter(City!="Chennai"| Rent<450000)%>% 
  filter(City!="Chennai"| Rent<200000)%>% 
  filter(City!="Bangalore"| Rent<250000)%>% 
  filter(City!="Hyderabad"| Rent<200000)%>% 
  filter(City!="Delhi"| Rent<250000)%>% 
  filter(City!="Kolkata"| Rent<180000)

# Perform a Kruskal-Wallis Test to find out whether there is significance difference
# between the type of tenant preferred in terms of rent in different city
for (i in 1:length(City_Name)){
  kw_test_tenant_rent <- rental_data3%>%filter(City==City_Name[i])
  cat("\n")
  print(sprintf("City: %s", City_Name[i]))
  print((kruskal.test(Rent~Tenant.Preferred, kw_test_tenant_rent))$p.value)
  
}

kw_test_tenant_rent <- rental_data3

wilcoxon_pairtest_tenant_rent_mumbai <- kw_test_tenant_rent %>%
  filter(City == "")

pairwise.wilcox.test(wilcoxon_pairtest_tenant_rent_mumbai$Rent, 
                     wilcoxon_pairtest_tenant_rent_mumbai$Tenant.Preferred)

#############


#                                     Analysis 5.1.3
#            Which types of preferred tenant does the outliers mostly belongs to?
#############

# The function below is use to generate a table to fill in outliers data from a city
outliers_empty_table <- subset(rental_data3, Rent == 0)

outliers_table <- function(numbOfCity, emptyTable)
{
  city_table <- subset(rental_data3, City == numbOfCity, select = c(Rent, Tenant.Preferred))
  
  LB = quantile((city_table$Rent), probs = 0.25) - (1.5*IQR(city_table$Rent))
  UB = quantile((city_table$Rent), probs = 0.75) + (1.5*IQR(city_table$Rent))
  
  temp_outliers_table <- filter(rental_data2, (Rent<LB|Rent>UB) & City==numbOfCity)
  
  outliers_table <- rbind(emptyTable, temp_outliers_table)
  
}


# The for loop code below is to combine all the outliers from different cities together
for (i in 1:length(City_Name)){
  outliers_empty_table <- outliers_table(City_Name[i], outliers_empty_table)
}


# The code below will be use to display a bar chart of number vs Tenant.Preferred
outlier_tenant_preferred <- outliers_empty_table%>%
  select(c("City", "Tenant.Preferred", "Rent"))%>%
  group_by(Tenant.Preferred, City)%>%
  summarise(number=n(), .groups = 'drop')

color_combination2 <- c(colorspace::heat_hcl(6))

ggplot(outlier_tenant_preferred, aes(x=Tenant.Preferred, y=number, fill=City))+
  geom_bar(stat = 'identity')+
  facet_wrap(~City)+
  geom_text(aes(label=number, vjust=-0.1))+
  scale_fill_manual(values=color_combination2)+
  ggtitle("Total Number of Different Tenant Type Across Cities")+
  theme(text = element_text(family = "Courier"))+
  theme(plot.title = element_text(face = "bold", hjust = 0.5))+
  ylab("Total")

# Trim dataset based on the previous analysis
outliers_empty_table <- outliers_empty_table %>% 
  filter(City!="Mumbai"| Rent<450000)%>% 
  filter(City!="Chennai"| Rent<280000)%>% 
  filter(City!="Chennai"| Rent<450000)%>% 
  filter(City!="Chennai"| Rent<200000)%>% 
  filter(City!="Bangalore"| Rent<250000)%>% 
  filter(City!="Hyderabad"| Rent<200000)%>% 
  filter(City!="Delhi"| Rent<250000)%>% 
  filter(City!="Kolkata"| Rent<180000)

#############

#                                     Analysis 5.1.4
# What are the average rent of those outliers based on the preferred tenant 
# across different cities?
#############

outlier_tenant_rent <- outliers_empty_table%>%
  select(c("City", "Tenant.Preferred", "Rent"))%>%
  group_by(City, Tenant.Preferred)%>%
  summarize(AVG_RENT = mean(Rent), .groups = 'drop')

color_combination5 <- c("#f7ecf9", "#dbd5fa", "#a5aff6", "#878bef", "#636adc", "#3b52d7")

ggplot(outlier_tenant_rent, aes(x=Tenant.Preferred, y=AVG_RENT, fill=City))+
  geom_bar(stat = 'identity', color="black")+
  facet_wrap(~City)+
  scale_fill_manual(values = color_combination5)+
  geom_text(aes(label=round(AVG_RENT, digits = 2)), vjust=-0.5)+
  ggtitle("Average Rent of Outliers vs Preferred Tenant Type Across Cities")+
  theme(plot.title = element_text(face = "bold", hjust = 0.5))+
  theme(text = element_text(family = "Courier"))+
  ylab("Average Rent") + xlab("Type of Preferred Tenant")

#############



#                                     Analysis 5.1.5
#       What are the relation between BHK and high rental fees across different cities?
#############

# The code below shows the frequency of post based on the number of BHK across different cities
fr_bhk_table <- rental_data3 %>%
  select(c("City", "Rent","BHK")) %>%
  group_by(City, BHK) %>%
  summarise(tot_number=n(), .groups = 'drop')

color_combination11 = c("#d3ebf8","#9bc2e5", "#6c80ca", "#48669c", "#1e284f", "#0f1331")

plot_for_BHK_Number<- ggplot(fr_bhk_table, aes(x=BHK, y=tot_number, fill=factor(BHK)))+
  geom_bar(stat='identity', color="black")+
  scale_fill_manual(values = color_combination11)+
  geom_text(aes(label=tot_number, vjust=-0.2))+
  facet_wrap(~City, ncol = 2)+
  ggtitle("Total Number vs BHK in Different Cities")+
  theme(plot.title = element_text(family = "Courier", colour = "darkblue", hjust = 0.5, face = "bold"))+
  labs(fill="BHK")
plot_for_BHK_Number


# Boxplot to show BHK vs Rent
bhk_and_rent_boxplot <- rental_data3 %>% select(c("City", "BHK", "Rent")) %>%
  group_by(City, BHK)

bhk_and_rent_boxplot_except_mumbai <- rental_data3 %>% select(c("City", "BHK", "Rent")) %>%
  filter(City!="Mumbai")%>%
  group_by(City, BHK)

color_combination6 <- c("#e9e1cf", "#e0d19b", "#e7e5d3", "#d9be71", "#dab2a3", "#be7e4e")

ggplot(bhk_and_rent_boxplot, aes(x=BHK, y=Rent, fill=City))+
  geom_boxplot(aes(group=BHK))+
  scale_fill_manual(values = color_combination6)+
  facet_wrap(~City)+
  stat_summary(fun=mean, geom = "point", shape=20)+
  ggtitle("Rent vs BHK Across City")+
  theme(plot.title = element_text(face = "bold"), legend.position = "none")+
  theme(text = element_text(family = "Courier"))

ggplot(bhk_and_rent_boxplot_except_mumbai, aes(x=BHK, y=Rent, fill=City))+
  geom_boxplot(aes(group=BHK))+
  scale_fill_manual(values = color_combination6)+
  facet_wrap(~City, nrow = 1)+
  stat_summary(fun=mean, geom = "point", shape=20)+
  ggtitle("Rent vs BHK Across City Without Mumbai")+
  theme(plot.title = element_text(face = "bold"), legend.position = "none")+
  theme(text = element_text(family = "Courier"))


# Second round of data trimming
# List out the top 10 highest rent based on condition
rental_data3 %>% filter(City=="Kolkata" & BHK ==6) %>% 
  arrange(desc(Rent)) %>%
  head(10)

# Trim using filter
rental_data3 <- rental_data3 %>% 
  filter(City!="Hyderabad"| Rent!=130000 | BHK!=2) %>% 
  filter(City!="Bangalore"| Rent!=70000 | BHK!=1) %>% 
  filter(City!="Chennai"| BHK!=6) %>% 
  filter(City!="Kolkata"| BHK!=6)  %>% 
  filter(City!="Kolkata"| BHK!=5)  %>% 
  filter(City!="Hyderabad"| BHK!=5)  %>% 
  filter(City!="Delhi"| BHK!=5)

outliers_empty_table <- outliers_empty_table %>% 
  filter(City!="Hyderabad"| Rent!=130000 | BHK!=2) %>% 
  filter(City!="Bangalore"| Rent!=70000 | BHK!=1) %>% 
  filter(City!="Chennai"| BHK!=6) %>% 
  filter(City!="Kolkata"| BHK!=6)  %>% 
  filter(City!="Kolkata"| BHK!=5)  %>% 
  filter(City!="Hyderabad"| BHK!=5)  %>% 
  filter(City!="Delhi"| BHK!=5)
  


# The code below shows the bar chart of average rent for different BHK which are
# being grouped by City
bhk_and_rent = select(rental_data3, c("Rent", "BHK", "City")) %>% 
  group_by(City, BHK) %>%
  summarise(AVG_RENT=round(mean(Rent), digits = 0), .groups = 'drop')
bhk_and_rent

plot_for_bhk_avgRent<-ggplot(bhk_and_rent, aes(x=BHK, y=AVG_RENT, fill=AVG_RENT)) +
    geom_bar(stat = 'identity')+
    scale_fill_gradient(low="lightgreen", high="darkgreen")+
    facet_wrap(~City)+
    ggtitle("Average Rent VS BHK Across Cities")+
    theme(plot.title = element_text(hjust = 0.5, face = "bold"))+
    theme(panel.background = element_rect("ivory"), panel.grid.major = element_line("darkgrey", size = 0.1))+
    geom_text(aes(label=round(AVG_RENT, digits = 2), vjust=-0.5))
plot_for_bhk_avgRent



# The code below shows the frequency of post based on the number of BHK across
# different cities from the outliers table
outliers_table_BHK <- outliers_empty_table %>% 
  select(c("City", "Rent", "BHK"))%>%
  group_by(BHK, City)%>%
  summarise(FREQ_BHK=n(), .groups='drop')
outliers_table_BHK

color_combination7 <- c("#cec4d6", "#c798a9", "#b47b8d", "#9c7163", "#6d5662", "#513a44")

plot_for_BHK_Number_outliers<-ggplot(outliers_table_BHK, aes(x=BHK, y=FREQ_BHK, fill=City))+
  geom_bar(stat = 'identity', color="black")+
  scale_fill_manual(values = color_combination7)+
  geom_text(aes(label=FREQ_BHK, vjust=-0.4))+
  facet_wrap(~City)+
  theme(legend.position = "none", plot.title = element_text(hjust = 0.5, face = "bold"))+
  ggtitle("Frequency of BHK Across Cities of Outliers")+
  ylab("BHK Frequency")+
  theme(text = element_text(family = "Courier"))

plot_for_BHK_Number_outliers



#Plot the density curve of Rent based on BHK
rent_density_plot <-rental_data3 %>%
  mutate(BHK = as.factor(BHK))
plot_rent_bhk_density <-ggplot(rent_density_plot, aes(x=Rent, fill=BHK))+
  geom_density(alpha=0.25)+
  facet_wrap(~City, ncol=2)+
  ggtitle("Density Plot of Rent Based on BHK In Different Cities")+
  theme(plot.title = element_text(hjust = 0.5), text = element_text(family = "Courier"))

plot_rent_bhk_density

#Plot the density curve of Rent based on BHK in Mumbai
rent_density_plot_mumbai <-rental_data3 %>%
  filter(City=="Mumbai")%>%
  mutate(BHK = as.factor(BHK))

plot_mumbai_rent_bhk_density<-ggplot(rent_density_plot_mumbai, aes(x=Rent, fill=BHK))+
  geom_density(alpha=0.25)+
  ggtitle("Density Plot for Rent of Different BHK in Mumbai")+
  theme(plot.title = element_text(hjust = 0.5), text = element_text(family = "Courier"))

plot_mumbai_rent_bhk_density


# Plot the density curve of Rent based on BHK for outliers table
rent_density_plot_outliers <- outliers_empty_table %>%
  mutate(BHK=as.factor(BHK))

plot_rent_bhk_density_outliers <-ggplot(rent_density_plot_outliers, aes(x=Rent, fill=BHK))+
  geom_density(alpha=0.25)+
  facet_wrap(~City)+
  ggtitle("Density Plot of Rent Based on BHK In Different Cities for Outliers Table")+
  theme(plot.title = element_text(hjust = 0.5), text = element_text(family = "Courier"))

plot_rent_bhk_density_outliers

ggplot(rent_density_plot_outliers%>%filter(City=="Mumbai"), aes(x=Rent, fill=BHK))+
  geom_density(alpha=0.25)+
  ggtitle("Density Plot of Rent Outliers Based on BHK In Mumbai")+
  theme(plot.title = element_text(hjust = 0.5), text = element_text(family = "Courier"))


# Conduct a Kruskal-Wallis Test to show whether there is a significance difference between BHK
# in Mumbai City in terms of rent
# H0: There is no significant difference between BHK interms of rent in Mumbai
# H1: There is a significant difference between BHK interms of rent in Mumbai
# Assumption of critical p-value will be 0.01
kw_test_bhk_rent_mumbai <- rental_data3%>%filter(City=="Mumbai")
kruskal.test(Rent~BHK, data = kw_test_bhk_rent_mumbai)
# Use pairwise wilcoxon test to find out which group combination have a significant difference
pairwise.wilcox.test(kw_test_bhk_rent_mumbai$Rent, kw_test_bhk_rent_mumbai$BHK)

#############


#                                     Analysis 5.1.6
#   What number of BHK occurs the most in every type of tenant across different cities?
#############

bhk_and_tenant <- rental_data3 %>%
  select(c("Tenant.Preferred","BHK", "City", "Rent"))%>%
  group_by(City, Tenant.Preferred, BHK)%>%
  summarise(tot_bhk=n(), .groups = 'drop')


plot_tenantnumb_vs_bhk <- ggplot(bhk_and_tenant, aes(x=BHK, y=tot_bhk, fill=Tenant.Preferred))+
  geom_bar(stat = 'identity')+
  facet_grid(Tenant.Preferred~City) +
  ggtitle("Frequency of BHK Based on Tenant Type Across Cities")+
  ylab("Total")+
  theme(plot.title = element_text(face = "bold", hjust = 0.5), 
        text = element_text(family = "Courier"), 
        legend.position = "none")+
  geom_text(aes(label=tot_bhk), vjust=-0.1)


plot_tenantnumb_vs_bhk

#############


#                                     Analysis 5.1.7
#         What are the relationship between size and Rent across different cities?
#############

# The code below is use to plot a scatter plot along with regression line 
# between size and rent across different cities
plot_for_size_rent <- ggplot(rental_data3, aes(x=Size, y=Rent, color=City))+
  geom_point(alpha=0.5)+
  stat_smooth(method = lm, color="black")+
  facet_wrap(~City)+
  ggtitle("Size vs Rent Across Cities")+
  theme(text = element_text(family = "Courier"), 
        plot.title = element_text(hjust = 0.5, face = "bold"), legend.position = "none")
  
plot_for_size_rent


# Plot a scatter plot with regression line in Mumbai
dat_for_scatplot_mumbai <- filter(rental_data3, City=="Mumbai")

sum_test <- summary(lm(Rent~Size, dat_for_scatplot_mumbai))
sum_test

ggplot(dat_for_scatplot_mumbai, aes(x=Size, y=Rent))+
  geom_point(color="#e8a244")+
  stat_smooth(method = lm)+
  annotate("text", x=3500, y = 1000,label = "r^2==0.74", parse=TRUE, size=6, family="Courier")+
  ggtitle("Size vs Rent In Mumbai")+
  theme(plot.title = element_text(face = "bold", hjust = 0.5), 
        text = element_text(family = "Courier"))


# Display all the coefficient of determination of rent vs size in every city
City <- c()
Coeff_Determination <-c(City=character(0), Coeff_Determination=numeric(0))

table_for_coeff_determination <- data.frame()

display_rsquare <- function(City_Name){
  City <- City_Name
  dat_for_scatplot <- filter(rental_data3, City==City_Name)
  rsquare_result <- summary(lm(Rent~Size, dat_for_scatplot))
  Coeff_Determination <-round(rsquare_result$r.squared, digits=2)
  combine_value <- data.frame(City=City, Coeff_Determination=Coeff_Determination)
  table_for_coeff_determination<<-rbind(table_for_coeff_determination, combine_value)
  
}

for (i in 1:length(City_Name)) {
  display_rsquare(City_Name[i])
}

#############


#                                     Analysis 5.1.8
#                 What are the relationship between Size and BHK?

#############

color_combination8 <- c("#f4dce1", "#e6a9ae", "#efaeaa", "#d5a190", "#a86d50", "#ba815b")

ggplot(rental_data3, aes(x=BHK, y=Size, fill=City))+
  geom_boxplot(aes(group=BHK))+
  facet_wrap(~City)+
  ggtitle("Boxplot for Size vs BHK")+
  scale_fill_manual(values = color_combination8)+
  theme(plot.title = element_text(hjust = 0.5, face = "bold", colour = "#16281d"), 
        text = element_text("Courier"), 
        legend.position = "none")+
  stat_summary(fun = mean, geom = "point", shape=20, color="yellow")


# Third round of data trimming
# List out the top 10 highest rent based on condition
rental_data3 %>% filter(City=="Kolkata", BHK==3) %>% 
  arrange((Size)) %>%
  head(10)

# Trim using filter
rental_data3 <- rental_data3 %>% 
  filter(City!="Kolkata"| Size<3500) %>% 
  filter(City!="Hyderabad"| Size!=100 | BHK!=4)%>% 
  filter(City!="Mumbai"| Size!=3700 | BHK!=4) %>% 
  filter(City!="Kolkata"| Size!=120 | BHK!=3)

outliers_empty_table <- outliers_empty_table %>% 
  filter(City!="Kolkata"| Size<3500) %>% 
  filter(City!="Hyderabad"| Size!=100 | BHK!=4)%>% 
  filter(City!="Mumbai"| Size!=3700 | BHK!=4) %>% 
  filter(City!="Kolkata"| Size!=120 | BHK!=3)


# Perform pairwaise wilcoxon test to test out the relation between size and bhk in Mumbai
wilcoxon_test_size_bhk_mumbai<-rental_data3%>%filter(City=="Mumbai")
pairwise.wilcox.test(wilcoxon_test_size_bhk_mumbai$Size, wilcoxon_test_size_bhk_mumbai$BHK)

#############


#                                     Analysis 5.1.9
#                 What size is more popular among different tenant across cities?
#############

color_combination9 <- c("#f6ae94", "#c55745", "#8d251d")

ggplot(rental_data3, aes(x=Tenant.Preferred, y=Size, fill=Tenant.Preferred))+
  geom_violin()+
  scale_fill_manual(values = color_combination9)+
  facet_wrap(~City)+
  ggtitle("Violin Plot for Size Vs Type of Tenant")+
  xlab("Type of Tenant")+
  theme(text = element_text("Courier"), 
        plot.title = element_text(face = "bold", color = "brown", hjust = 0.5), 
        legend.position = "none")


# Conduct hypothesis testing to find out whether there are any difference in terms of rent
# between different tenant group in Mumbai
# Assume the critical p-value to be 0.05
kruskal.test(Size~Tenant.Preferred, data=rental_data3%>%filter(City=="Mumbai"))
pairwise.wilcox.test((rental_data3%>%filter(City=="Mumbai"))$Size, 
                     (rental_data3%>%filter(City=="Mumbai"))$Tenant.Preferred)

#############


#                                     Analysis 5.1.10
#         How does a furnishing status affect the rental fees in different city ?

#############

# Find out the total number of different furnishing status in different cities

numbOfFurnishingStatus <- select(rental_data3, c("City", "Furnishing.Status", "Tenant.Preferred")) %>%
  group_by(City, Furnishing.Status) %>%
  summarise(number=n(), .groups='drop')
numbOfFurnishingStatus


totNumbInCity <- rental_data3 %>% select(c("City", "Furnishing.Status")) %>%
  group_by(City) %>%
  summarise(tot_number=n(), .groups='drop')
totNumbInCity

joint_table <- (right_join(numbOfFurnishingStatus, totNumbInCity)) %>%
  mutate(percentage = round((number/tot_number)*100, digits = 2))


ggplot(joint_table, aes(x=City, y=number, fill=Furnishing.Status)) +
  geom_col(width=0.7, position="dodge")+
  scale_fill_manual(values = c("chocolate4", "darkgoldenrod", "bisque3"))+
  geom_text(aes(label=percentage), position=position_dodge(0.8), vjust=-0.5)


# Find out whether most of the outliers in Mumbai comes from fully furnished house.
outlier_numb_vs_furnish_status <-
  outliers_empty_table %>%
  group_by(City, Furnishing.Status)%>%
  summarise(numb=n(), .groups = 'drop')

color_combination10 <- c("#a6ddff", "#5ec4ef", "#1a9ae6", "#146bdc", "#003986", "#081559")

ggplot(outlier_numb_vs_furnish_status, aes(x=Furnishing.Status, y=numb, fill=City))+
  geom_bar(stat = 'identity', color="black")+
  scale_fill_manual(values = color_combination10)+
  facet_wrap(~City)+
  geom_text(aes(label=numb, vjust=-0.2))+
  ggtitle("Frequency of Furnishing Status Across Cities for Outliers")+
  theme(legend.position = "none", 
        text = element_text(family = "Courier"), 
        plot.title = element_text(hjust = 0.5, face = "bold"))


# Find the relation between rental fees and furnishing status across different city
ggplot(rental_data3, aes(x=Furnishing.Status, y=Rent, fill=Furnishing.Status))+
  geom_boxplot(aes(group=Furnishing.Status))+
  facet_grid(~City)+
  stat_summary(fun = mean, geom = "point", shape=20, color="yellow")+
  theme(axis.text.x = element_blank(), 
        plot.title = element_text(face = "bold", hjust = 0.5), 
        text = element_text(family = "Courier"))+
  ggtitle("Rent vs Furnishing Status Across Cities")


# By focusing in Mumbai city, conduct a test to test out whether there is a significance difference
# between furnishing status in terms of rent
# H0: There is no significance different between furnishing status in terms of rent
# H1: There is significance different between furnishing status in terms of rent
data_for_test_furnish_vs_rent_mumbai <- rental_data3%>%filter(City=="Mumbai")

# Conduct Kruskal-Wallis Test and Post-hoc test
kruskal.test(Rent~Furnishing.Status, data=data_for_test_furnish_vs_rent_mumbai)

dunn.test(data_for_test_furnish_vs_rent_mumbai$Rent, 
          g=data_for_test_furnish_vs_rent_mumbai$Furnishing.Status)

#############










#Soo Jiun Guan, TP068687

#==========LIBRARY==========
install.packages("dplyr")
install.packages("ggplot2")
library(dplyr)
library(ggplot2)

#==========IMPORT DATASET==========

rental_data <- read.csv("C:\\Users\\Admin\\OneDrive - Asia Pacific University\\year 2\\sem 1\\Programming for Data Analysis\\Assignment\\group\\House_Rent_Dataset.csv", header = TRUE)

#==========DATA CLEANING==========

#Remove Missing Values
omit_data <- na.omit(rental_data)

#Remove Duplicated Rows
rental_data <- unique(rental_data)

#Check Data
unique(rental_data$Area.Type)
unique(rental_data$Tenant.Preferred)
unique(rental_data$Furnishing.Status)
unique(rental_data$Point.of.Contact)

#REMOVE SPECIAL ROWS
View(filter(rental_data, rental_data$Area.Type == "Built Area"))
View(filter(rental_data, rental_data$Point.of.Contact == "Contact Builder"))
rental_data2 <- filter(rental_data, Area.Type != "Built Area" 
                       & Point.of.Contact != "Contact Builder")

# REMOVE OUTLIERS
sort(unique(rental_data$Rent), decreasing=TRUE) # check is there any outliers
rental_data2 <- filter(rental_data2, Rent < 1000000)

View(rental_data2)


#==========DATA EXPLORATION==========

#structure
str(rental_data)

#number of rows and columns
dim(rental_data)

#column names
names(rental_data)

#statistical summary
summary(rental_data)

# evaluates whether the "Size" and "Rent" variable is normally distributed
shapiro.test(rental_data3$Size)
shapiro.test(rental_data3$Rent)


#==========DATA ANALYSIS==========

# Q4: Does the type of person who posted this rental determine the rent across different cities? 
# To discover the relationship between the type of person who post their rental information and rent across different cities.

#ANALYSIS 1： How much is the rental information posted by both contact points across different cities?
contact_count <- rental_data2 %>%
  filter(Point.of.Contact %in% c("Contact Owner", "Contact Agent")) %>%
  count(City, Point.of.Contact)

#Extra feature 1: count()
#use to count the how much times each unique value appears

ggplot(contact_count, aes(x = City, y = n, fill = Point.of.Contact)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.8) +
  geom_text(aes(label = n, fontface = "bold"), 
            position = position_dodge(width = 0.8), vjust = -0.5) +
  labs(x = "City", y = "Count", 
       title = "Counts of Contact Point across Different Cities") +
  theme(plot.title = element_text(hjust = 0.5))

#Extra feature 2: labs()
#set the title, as well as add labels to the x-axis and the y-axis of the plot 

#Extra feature 3: theme()
#customize elements of the plots like the colors, fonts, legends, labels, and so on

##########

#ANALYSIS 2: How about the average rent posted by both contact points across different cities? 
average_rent <- rental_data2 %>%
  group_by(City, Point.of.Contact) %>%
  summarise(Average_Rent = mean(Rent))

ggplot(average_rent, aes(x = City, y = Average_Rent, color = Point.of.Contact)) +
  geom_point(size = 3, aes(shape = Point.of.Contact)) +
  geom_line(aes(group = Point.of.Contact, linetype = Point.of.Contact)) +
  labs(x = "City", y = "Average Rent", 
       title = "Average Rent Posted by Each Contact Point across Different Cities") +
  theme_minimal()

#Extra feature 4: theme_minimal()
#remove the background elements and decorations of the plot

##########

#Hypothesis Testing

#check rent is normal distribution or not
#Shaprio Test
shapiro.test(rental_data3$Rent)
#Historgram
ggplot(rental_data2, aes(x = Rent)) +
  geom_histogram() +
  labs(title = "Histogram of Rent") +
  theme_minimal()
#Q-Q Plot
qqnorm(rental_data2$Rent)
qqline(rental_data2$Rent)
shapiro.test(rental_data2$Rent) #the rent is not normally distributed

#Wilcoxon Rank Sum Test
City_Name <- unique(rental_data2$City)
for (i in 1:length(City_Name)){
  filtered_city_row <- rental_data2%>%filter(City==City_Name[i])
  cat("\n")
  print(sprintf("Kruskal Walts Test in %s", City_Name[i]))
  print((wilcox.test(Rent~Point.of.Contact, filtered_city_row))$p.value)
}

#H0: There is no significant difference in rent across different cities based on the point of contact.
#H1: There is a significant difference in rent across different cities based on the point of contact.
#Since the P-Value is lower than the critical value 0.05 that we assumed; Reject H0; Accept H1. Therefore, there are significant differences in rent between the cities based on the point of contact.

#Extra feature 5: wilcox.test()
#perform a Wilcoxon rank sum test to compare two paired groups

##########

#Analysis 3: what is the relationship between average rent and BHK posted by each contact point across different cities?
avgrent_bhk <- rental_data2 %>%
  group_by(City, BHK, Point.of.Contact) %>%
  summarise(Average_Rent = mean(Rent))

ggplot(avgrent_bhk, aes(x = BHK, y = Average_Rent, color = Point.of.Contact)) +
  geom_point() +
  geom_line() +
  facet_wrap(~ City, scales = "fixed") +
  labs(x = "BHK", y = "Average Rent",
       title = "Relationship between Average Rent and BHK Posted by 
       Each Contact Point across Different Cities") +
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5))

##########

#ANALYSIS 4: What is the relationship between rent and size posted by each contact point across different cities?
ggplot(rental_data2 , aes(x = Size, y = Rent, col = Point.of.Contact)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color ="#7CFC00") +
  facet_grid(Point.of.Contact~ City, scales = "free_x") +
  labs(x = "Size", y = "Rent", 
       title = "Relationship between Rent and Size 
       Posted by Each Contact Point across Different Cities") +
  theme(legend.position = "bottom", 
        plot.title = element_text(hjust = 0.5)) +
  theme(axis.text.x = element_text(angle = 75, hjust = 1))

##########

#ANALYSIS 5: How about the impact of the interconnection between property size and rent across different cities and lessors?
slopes_rent_size <- rental_data2 %>%
  group_by(City, Point.of.Contact) %>%
  summarize(Slope = coef(lm(Rent ~ Size))[2])
View(slopes_rent_size)

##########

#ANALYSIS 6: How about the strength of linear relationship between property size and rent in different cities based on different point of contact?
correlation_rent_size <- rental_data2 %>%
  group_by(City, Point.of.Contact) %>%
  summarize(Correlation = cor(Size, Rent))
View(correlation_rent_size)

##########

#ANALYSIS 7: What is the relationship between rent and area type posted by each contact point across different cities?
#480 rows
sampling <- rental_data2 %>%
  group_by(City,Area.Type,Point.of.Contact) %>%
  sample_n(20, replace = FALSE )

ggplot(sampling, aes(x = Area.Type, y = Rent, fill = Point.of.Contact)) +
  geom_boxplot() +
  facet_wrap(~ City, scales = "free_y") +
  ggtitle("Relationship between Rent and Area Type Posted by Each Contact Point 
          across Different Cities") +
  xlab("Area Type") +
  ylab("Rent") +
  theme(legend.position = "bottom", plot.title = element_text(hjust = 0.5)) 

medians_rent_areatype <- sampling %>%
  group_by(City, Area.Type, Point.of.Contact) %>%
  summarise(Median.Rent = median(Rent))

medians_list <- split(medians_rent_areatype, medians$City)

#Extra feature 6: split()
#divide a data frame into separate subsets based on the unique values in the specific column

for (city_name in names(medians_list)) {
  cat("Median Rent for", city_name, "\n")
  print(medians_list[[city_name]])
  cat("\n")
}

##########

#Analysis 8: What is the relationship between rent and furnishing status posted by each contact point across different cities?
#360 rows
sampling2 <- rental_data2 %>%
  group_by(City,Furnishing.Status,Point.of.Contact) %>%
  sample_n(10, replace = FALSE )

ggplot(sampling2, aes(x = Furnishing.Status, y = Rent, fill = Point.of.Contact, 
                      color = Furnishing.Status)) +
  geom_violin() +
  facet_wrap(~ City, scales = "free_y") +
  ggtitle("Relationship between Rent and Furnishing Status 
          Posted by Each Contact Point across Different Cities") +
  xlab("Furnishing Status") +
  ylab("Rent") +  
  scale_color_manual(values = c("green", "brown", "blue")) + 
  theme(legend.position = "bottom", legend.direction = "vertical", 
        plot.title = element_text(hjust = 0.5),
        axis.text.x = element_blank())

#Extra feature 7: geom_violin()
#use to create a violin plot

##########

#Categorical:
#Bar plot

#Continuous:
#Histograms
#Kernel density estimation plot
#Box plots
#Bivariate

#Categorical x categorical
#Heat map of contingency table
#Multiple bar plots

#Categorical x continuous
#Box plots of continuous for each category
#Violin plots of continuous distribution for each category
#https://ggplot2.tidyverse.org/reference/geom_violin.html
#Overlaid histograms (if 3 or less categories)

#Continuous x continuous
#Scatter plots
#Hexibin plots
#Joint kernel density estimation plots
#Correlation matrix heatmap

#unused /no anyone use floor column/
#DATA TRANSFORMATION
#trans_data <- rental_data2 %>%
#mutate(
#Floor = gsub("(\\d+) out of (\\d+)", "\\1:\\2", Floor),
#Floor = gsub("Ground out of (\\d+)", "1:\\1", Floor),
#Floor = gsub("Upper Basement out of (\\d+)", "UPB:\\1", Floor), #UPB:Upper Basement
#Floor = gsub("Lower Basement out of (\\d+)", "LWB:\\1", Floor)) #LWB:Lower Basement
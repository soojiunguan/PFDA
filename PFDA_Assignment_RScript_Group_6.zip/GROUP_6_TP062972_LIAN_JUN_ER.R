# Lian Jun Er, TP062972

#========== Library ==========

install.packages("dplyr")
install.packages("ggplot2")
library(dplyr)
library(ggplot2)

#========== Data Import ==========

rental_data = read.csv("C:\\Users\\User\\OneDrive - Asia Pacific University\\APU\\Degree\\YEAR 1\\PFDA\\House_Rent_Dataset.csv",header=TRUE)
rental_data

#========== Data Cleanning ==========
names(rental_data) =c("DATE_POST","NUM_BHK","AMT_RENT","HOUSE_SIZE","FLOOR","TYPE_OF_AREA","AREA_LOCALITY","HOUSE_CITY","STATUS_OF_FURNISHING","PREFERABLE_OF_TENANT","NUM_BATHROOM","PERSON_CONTACT")
rental_data

rental_data <- unique(rental_data)

clean_data <- na.omit(rental_data)

colSums(is.na(rental_data))

unique(rental_data$Point.of.Contact)

unique(rental_data$Area.Type)

View(filter(rental_data2, rental_data2$Area.Type == "Built Area"))

View(filter(rental_data2, rental_data2$Point.of.Contact == "Contact Builder"))

rental_data <- filter(rental_data, Rent != 3500000 & Rent != 1200000 & Rent !=1000000 &
                        Area.Type!="Built Area" & Point.of.Contact!="Contact Builder")

#========== Analysis ==========

# 1) How many times each type of tenant preference appears in posts from that city?
tenant_counts <- rental_data %>%
  group_by(City, Tenant.Preferred) %>%
  summarize(Count = n())

ggplot(tenant_counts, aes(x = Tenant.Preferred, y = Count, fill = Tenant.Preferred)) +
  geom_bar(stat = "identity") +
  theme_minimal() +
  labs(title = "Distribution of Tenant Preferences by City", x = "Tenant Preference", y = "Count") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  facet_wrap(~ City, ncol = 6) +
  geom_text(aes(label=Count))


# 2)  What is the correlation between specific tenant preferences and higher rental prices in certain cities?
correlation_plot <- rental_data %>%
  group_by(City, Tenant.Preferred);

ggplot(correlation_plot, aes(x = Tenant.Preferred, y = Rent, col = Tenant.Preferred)) +
  geom_point() +
  scale_y_continuous(labels = comma)+
  theme_minimal() +
  labs(title = "Correlation Between Tenant Preferences and Rental Prices", x = "Tenant Preference", y = "Rent") +
  theme(axis.text.x = element_text(angle = 75, hjust = 1))+
  facet_grid(~ City, scales = "free_x")


# 3) How do tenant preferences vary with the number of bedrooms (BHK) in certain cities?
plot_for_BHK_tenan_prefer <- rental_data %>%
  group_by(BHK, Tenant.Preferred, City);
  
ggplot(plot_for_BHK_tenan_prefer, aes(x=Tenant.Preferred, y=BHK, color=City))+
  geom_point(alpha=0.5)+
  labs(x = "BHK", Y= "Count", titlle ="BHK vs Tenant Preferred Across Cities")+
  facet_wrap(~City)+
  theme_minimal()+
  theme(axis.text.x = element_text(hjust = 0.5, angle = 45))


# 4) Is there a correlation between furnish status and different number of BHK in various cities?
furnish_BHK <- rental_data %>%
  group_by(BHK, Furnishing.Status, City);

color_combination <- c("#99CCFF", "#3366CC", "#003399")

ggplot(furnish_BHK, aes(x=Furnishing.Status, y=BHK, fill=Furnishing.Status))+
  geom_violin()+
  scale_fill_manual(values = color_combination)+
  facet_wrap(~City)+
  ggtitle("Furnish Status vs. BHK in Various Cities")+
  theme(plot.title = element_text(face = "bold", color = "brown", hjust = 0.5), 
        legend.position = "none")

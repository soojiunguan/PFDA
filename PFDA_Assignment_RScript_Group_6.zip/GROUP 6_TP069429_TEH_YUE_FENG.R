# Teh Yue Feng, TP069429


# ------------------------------------------------------------------------------------------
install.packages("dplyr")
install.packages("ggplot2")
install.packages("plotrix")
install.packages("vcd")
install.packages("readxl")
library(dplyr)
library(ggplot2)
library(plotrix)
library(vcd)
library(readxl)
# ------------------------------------- IMPORT DATASET -------------------------------------

rental_data <- read.csv("C:\\Users\\User\\Desktop\\APD2F2305CS (DA)\\SEM 1\\Programming of Data Analysis\\Assignment\\House_Rent_Dataset.csv" , 
                        header = TRUE)

# ------------------------------------- DATA CLEANING --------------------------------------

rental_data <- na.omit(rental_data)
nrow(rental_data)

rental_data <- unique(rental_data)
nrow(rental_data)

View(rental_data)
names(rental_data)

# There are two special rows which contains "Built Area" as Area Type
# Another one special row contain "Contact Builder" as it's point of contact

unique(rental_data$Point.of.Contact)
View(filter(rental_data, rental_data$Area.Type == "Built Area"))
View(filter(rental_data, rental_data$Point.of.Contact == "Contact Builder"))

# REMOVE OUTLIERS FROM BANGALORE & CONTACT_BUILDER FROM POINT.OF.CONTACT

rental_data2 <- filter(rental_data, Rent != 3500000 & Rent != 1200000 & Rent !=1000000 &
                         Area.Type!="Built Area" & Point.of.Contact!="Contact Builder")

View(rental_data2)
nrow(rental_data2)

# ---------------------------------- DATA PRE-PROCESSING ----------------------------------

# 1. How many "Cities" are there? 
  unique(rental_data2$City)  ## SHOW THE CITY NAMES

  cities <- nlevels(factor(rental_data2$City))  ## SHOW THE TOTAL NUMBER OF CITIES
  cities
  
# 2. How many type of "Point.of.Contact" in the Rent_Data?
  
  point_contact <- levels(factor(rental_data2$Point.of.Contact))
  point_contact
  
# 3. THE (MIN) & (MAX) of "Point.of.Contact"
  
  max(rental_data2$Point.of.Contact)    # "CONTACT OWNER"
  min(rental_data2$Point.of.Contact)    # "CONTACT AGENT"
  
# 4. Convert data in Posted.On from CHARACTER into DATE
  rental_data$Posted.On <- as.Date(rental_data$Posted.On, format = "%m/%d/%Y")
  View(rental_data)
  
# ------------------------------------- DATA ANALYSIS -------------------------------------
#                                         Question 2.
##          Does number of both rental posts by agents and owners varies across cities?  
##                          To investigate the relationship between
##                      The total number of different types of stakeholders 
##                                            &
##                                The cities they are locate. 
  
  # ---         ANALYSIS 1-1: Find the relationship between "Point.of.Contact" & "City". ---
    #                         HOW MANY TYPE OF POINT.OF.CONTACT? 
  point_contact <- levels(factor(rental_data2$Point.of.Contact))
  point_contact
  
    #           --- ANALYSIS 1-2: WHAT ARE THE OVERALL PERCENTAGE OF POINT.OF.CONTACT? ---
  total_agents <- sum(rental_data2$Point.of.Contact == "Contact Agent")
  total_owners <- sum(rental_data2$Point.of.Contact == "Contact Owner")
  total_poc <- total_agents + total_owners
  
  contact_counts <- data.frame(
    Point.of.Contact = c("Contact Agent", "Contact Owner"),
    Count = c(total_agents, total_owners) )

  cus_col = c("#8AB5DC","skyblue", "#6082B6", "steelblue", "#426484", "#16212C")

  pie3D(contact_counts$Count, 
        labels = contact_counts$Label, 
        col = cus_col,
        main = "PIE CHART: Points of Contact",
        border = "black",
        explode=0.08)
  
      
  #           --- ANALYSIS 1-3: WHAT ARE THE PERCENTAGES OF POINT.OF CONTACT BY EACH CITY? ---
  
  proportion_poc <- rental_data2 %>%
    group_by(City, Point.of.Contact) %>%
    summarise(Count = n())

  proportion1 <- proportion_poc %>% # CALCULATE PROPORTIONS
    group_by(City) %>%
    mutate(TotalContacts = sum(Count),
           Proportion = Count / TotalContacts)

  ggplot(proportion1, aes(x = City, y = Proportion, fill = Point.of.Contact)) +
    geom_bar(stat = "identity") +
    labs(title = "Proportion of Contacts with Agent vs Owner by City",
         x = "City",
         y = "Proportion") +
    geom_text(aes(label = scales::percent(Proportion)),
              position = position_stack(vjust = 0.5)) +
    theme_minimal() +
    scale_fill_manual(values = c("Contact Agent" = "skyblue", "Contact Owner" = "steelblue"))
  
  #       ---   ANALYSIS 1-4: Find the relationship between "Point.of.Contact" & "Rent". ---
  #             ---     THE RENT RANGE OF EITHER POINT.OF.CONTACT BY EACH CITY   ---

    rent_ranges <- c(0, 10000, 30000, 60000, 100000, 125000, Inf)
    categorize_rent <- function(rent) {
      cut(rent, breaks = rent_ranges, labels = c("<10k", "10k-30k", "30k-60k", 
                                                "60k-100k", "100k-125k", ">125k"), include.lowest = TRUE)
                                      }
    # CATEGORIZE RENTS & CALCULATE PREFERRED POINT OF CONTACT IN EACH CITY
  preferred_poc2 <- rental_data2 %>%
    mutate(Rent = categorize_rent(Rent)) %>%
    group_by(City, Rent, Point.of.Contact) %>%
    summarise(TOTAL = n()) %>%
    arrange(City, Rent, desc(TOTAL)) %>%
    select(City, Rent, Point.of.Contact, TOTAL)
    # CREATE A BARPLOT WITH FACETS FOR EACH CITY & EACH CATEGORY
  ggplot(preferred_poc2, aes(x = Point.of.Contact, y = TOTAL, fill = TOTAL)) +
    geom_bar(stat = "identity", width = 0.75) +
    labs(title = "Preferred Point of Contact by City and Rent Range",
       x = "Point of Contact",
       y = "RESULT") +
    theme_minimal() +
    geom_text(aes(label = TOTAL)) +
    scale_fill_gradientn("TOTAL", colors = cus_col) +
    facet_grid(City ~ Rent, scales = "free_y", space = "free") +
    theme(axis.text.y.left = element_blank())
  
    #                               INSIDE EACH CITY'S POSTED.ON, 
    #                   WHAT TYPE OF BHK'S ARE TRENDING IN THE MONTHS OF RENT 
    #                                             & 
    #                         WHICH POC DO THESE PEOPLE ASPIRE TO MORE?
    #             ANALYSIS 1-5: HOW ABOUT THE AVERAGE RENT IN EACH MONTH IN EACH CITY?
  
  avgrent_month <- rental_data2 %>%
    group_by(Month = month(Posted.On), City) %>%
    summarise(AVG_RENT_MONTHLY = mean(Rent, na.rm = TRUE)) %>%
    ungroup()
  
  ggplot(avgrent_month, aes(x = Month, y = AVG_RENT_MONTHLY, group = City, color = City)) +
    geom_line(size = 1.5, linetype = "solid", color = "black") +
    geom_point(size = 4, shape = 16) +
    geom_text(aes(label = sprintf("$%d", round(AVG_RENT_MONTHLY))), vjust = -1) +
    scale_x_continuous(breaks = 1:12, labels = month.name[1:12]) +
    labs(x = "Month", y = "Average Rent", title = "Average Monthly Rent by City") +
    scale_color_manual(values = cus_col) +
    theme_minimal() +
    theme(  plot.title = element_text(size = 12, hjust = 0.5),
            axis.text.x = element_text(angle = 45, hjust = 1)  ) +
    theme(  plot.margin = margin(1, 1, 1, 1, "cm"),
            panel.spacing = unit(0.1, "lines")  ) +
    facet_wrap(~ City, ncol = 2)
  
  #           ---   ANALYSIS 1-6: WHICH TYPE OF BHK IS THE MOST PREFERABLE BY EACH CITY? ---
  
  agg_data <- rental_data2 %>%
    group_by(City, BHK) %>%
    summarize(Count = n())
  
  ggplot(agg_data, aes(x = BHK, y = Count, color = City)) +
    geom_point(position = position_dodge(width = 0.2), size = 3) +
    labs(x = "BHK", y = "Count", title = "BHK Types in Different Cities")+ 
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 2)) +
    scale_color_manual(values = c(cus_col))
  
  #           ANALYSIS 1-7: TENANT MORE PREFER WHICH POINT.OF.CONTACT IN EACH MONTH WITH MAXIMUM COUNT?
  
  preferred_poc3 <- rental_data2 %>%
    group_by(Posted.On, Point.of.Contact, Tenant.Preferred) %>%
    summarise(Count = n()) %>%
    arrange(Posted.On, Tenant.Preferred, desc(Count))
  maxpoc_monthly1 <- preferred_poc3 %>%
    group_by(Posted.On, Tenant.Preferred) %>%
    filter(Count == max(Count)) %>%
    ungroup()
  
  ggplot(maxpoc_monthly1, aes(x = Posted.On, y = Count, fill = Point.of.Contact)) +
    geom_area(position = "stack") +
    labs(title = "Maximum Count of Point of Contact by Month for Each Tenant Preference",
         x = "Month",
         y = "Count",
         fill = "Point of Contact") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          legend.position = "bottom") +
    scale_fill_manual(values = c("Contact Agent" = "skyblue", "Contact Owner" = "#426484")) +
    facet_wrap(~ Tenant.Preferred, ncol = 1)
  
  #         ANALYSIS 1-8: TENANT MORE PREFER WHICH POINT.OF.CONTACT IN EACH MONTH WITH MINIMUM COUNT?
  
  preferred_poc4 <- rental_data2 %>%
    group_by(Posted.On, Point.of.Contact, Tenant.Preferred) %>%
    summarise(Count = n()) %>%
    arrange(Posted.On, Tenant.Preferred, Count)
  minpoc_monthly <- preferred_poc4 %>%
    group_by(Posted.On, Tenant.Preferred) %>%
    filter(Count == min(Count)) %>%
    ungroup()
  
  ggplot(minpoc_monthly, aes(x = Posted.On, y = Count, fill = Point.of.Contact)) +
    geom_point(stat = "identity", shape = 21, size = 3.5, color = "black") +
    geom_line(aes(x = Posted.On, y = Count, group = Tenant.Preferred, 
                  color = Tenant.Preferred), size = 0.8) +
    labs(title = "Point of Contact with Minimum Count by Month for Each Tenant Preference",
         x = "Month",
         y = "Count",
         fill = "Point of Contact") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          legend.position = "bottom") +
    scale_fill_manual(values = c("Contact Agent" = "skyblue", "Contact Owner" = "#426484")) +
    scale_color_manual(values = c("Family" = "black", "Bachelors" = "darkgrey", 
                                  "Bachelors/Family" = "grey")) +
    facet_wrap(~ Tenant.Preferred, ncol = 1)
  
  #                                   HYPOTHESIS TESTING
  
  # CHI-SQUARE TEST
      test1 <- xtabs(~City + Point.of.Contact, rental_data2 )
      chisq.test(test1)
      assocstats(test1)
      View(test1)
      # H0: Both City and Point of contact are not related
      # H1: Both City and Point of contact are related
      # Since the p-value is lower than the critical value 0.01 that we assumed
      # Reject H0; Accept H1
      # Therefore, we will conclude that both City and Point of contact are related
      
      test2 <- xtabs(~Point.of.Contact + Tenant.Preferred, rental_data2)
      chisq.test(test2)
      assocstats(test2)
      View(test2)
      
      # H0 : Both point of contact and tenant preferred are not related.
      # H1 : Both point of contact and tenant preferred are related.
      # Since the P-Value is lower than the critical value 0.05 that we assumed
      # Reject H0; Accept H1
      # Therefore, we will conclude that both City and Point of Contact are related.

# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---
  
  